import matplotlib.pyplot as plt

plt.figure() # 그리는 판 객체를 생성 하는 명령어 생략 가능

plt.title("Plot") # 제목 설정

# x가      0,1,2,3 의 y값
plt.plot([1,4,9,16]) #
plt.show() # 그려진것을 보여 줘라.


