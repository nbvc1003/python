import matplotlib.pyplot as plt

plt.title("Plot")
#         x값            y값
plt.plot([10,20,30,40], [1,4,9,16])
plt.show()

